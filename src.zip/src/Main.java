public class Main {
    public static void main(String[] args) {

        Professor professor = new Professor("Mariana", "000000000");

        Disciplina disciplina = new Disciplina("Prog Orientada a Obj", professor);

        Aluno aluno = new Aluno("Rafael", "111111111");
        disciplina.matricularAluno(aluno);

        disciplina.matricularAluno(new Aluno("Matheus", "222222222"));

        disciplina.matricularAluno(new Aluno("Gustavo", "333333333"));

        disciplina.matricularAluno(new Aluno("Roberto", "555555555"));

        disciplina.matricularAluno(new Aluno("Eduarda", "666666666")); 

        disciplina.matricularAluno(new Aluno("Rafaela", "777777777"));  

        disciplina.matricularAluno(new Aluno("Otto", "888888888")); 

        disciplina.matricularAluno(new Aluno("Marcos", "999999999"));  

        disciplina.matricularAluno(new Aluno("Eduardo", "101010101")); 
        
        disciplina.matricularAluno(new Aluno("Fabian", "101010102"));  

        disciplina.matricularAluno(new Aluno("Carlos", "101010103"));  // Carlos não será matriculado, turma lotada.

        EscolaPolitecnica politecnica = new EscolaPolitecnica(new Professor("Mariana", "000000000"));

        System.out.println("Nome do professor na classe Main: " + professor.getNome());
        disciplina.imprimirInfo();
        System.out.println("Professor da politécnica: " + politecnica.getNomeProfessor() + "\n");

        disciplina.substituirProfessor("444444444", "Cristina");

        System.out.println("Nome do professor na classe Main: " + professor.getNome());
        disciplina.imprimirInfo();
        System.out.println("Professor da politécnica: " + politecnica.getProfessor().getNome());

        System.out.println(professor);
        System.out.println(disciplina.getProfessor());
    }
}



// Mariana G. Cavilha, Rafael Segatto, Rafael Brensen & Gerson ;